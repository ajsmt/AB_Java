import javax.swing.JFrame;

public class Main {
    public static void main(String[] args) {
        JFrame frame = new MyFrame("Task_2");
    }
}